<<<<<<< HEAD
# streamlit-lbw-app
Hosting ML Model LBW
=======
{"nbformat":4,"nbformat_minor":0,"metadata":{"colab":{"provenance":[],"authorship_tag":"ABX9TyPU6WZjwzZlrCJ8+4Rc2g2U"},"kernelspec":{"name":"python3","display_name":"Python 3"},"language_info":{"name":"python"}},"cells":[{"cell_type":"code","execution_count":null,"metadata":{"id":"WT0LXN49HiQY"},"outputs":[],"source":["# Streamlit LBW Predictor — Step 1 (Train + Save)\n","\n","This repository contains:\n","- train_pipeline.py  — trains pipeline and saves model/pipeline.pkl and model/background.csv\n","- app.py             — Streamlit app (form → predict → SHAP)\n","- requirements.txt\n","\n","## Quick start (Google Colab recommended)\n","\n","1. Open Google Colab → New Python 3 notebook.\n","2. Upload this repo (or copy files into Colab).\n","3. Install packages:\n"]}]}
>>>>>>> 01e40f0 (Initial commit from Colab)
